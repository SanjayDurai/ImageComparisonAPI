AlgART is an open-source Java library, 
supporting generalized smart arrays and matrices of any Java types 
and a wide set of algorithms of their processing.

This library is distributed under the MIT license.

Please see http://algart.net/java/AlgART/ for more details.
