/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2007-2013 Daniel Alievsky, AlgART Laboratory (http://algart.net)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package net.algart.matrices.stitching;

import net.algart.math.functions.Func;

import java.util.List;

public final class CoordinateFreeStitchingMethod<P extends FramePosition> implements StitchingMethod<P> {
    private final Func combiningFunc;
    private final boolean standardBehaviorForSingleFrame;

    private CoordinateFreeStitchingMethod(Func combiningFunc, boolean standardBehaviorForSingleFrame) {
        if (combiningFunc == null)
            throw new NullPointerException("Null combiningFunc");
        this.combiningFunc = combiningFunc;
        this.standardBehaviorForSingleFrame = standardBehaviorForSingleFrame;
    }

    public static <P extends FramePosition> CoordinateFreeStitchingMethod<P> getInstance(Func combiningFunc) {
        return new CoordinateFreeStitchingMethod<P>(combiningFunc, true);
    }

    public static <P extends FramePosition> CoordinateFreeStitchingMethod<P> getInstance(
        Func combiningFunc, boolean standardBehaviorForSingleFrame)
    {
        return new CoordinateFreeStitchingMethod<P>(combiningFunc, standardBehaviorForSingleFrame);
    }

    public Func combiningFunc() {
        return combiningFunc;
    }

    public boolean simpleBehaviorForEmptySpace() {
        return true;
    }

    public boolean simpleBehaviorForSingleFrame() {
        return standardBehaviorForSingleFrame;
    }

    public StitchingFunc getStitchingFunc(List<? extends Frame<P>> frames) {
        if (frames == null)
            throw new NullPointerException("Null frames argument");
        return new StitchingFunc() {
            /*Repeat() ( double)\s*\[\]\s+values ==>
                       $1 v0,,$1 v0,$1 v1,,$1 v0,$1 v1,$1 v2,,$1 v0,$1 v1,$1 v2,$1 v3,,$1 v0,$1 v1,$1 v2,$1 v3,$1 v4,,
                       $1 v0,$1 v1,$1 v2,$1 v3,$1 v4,$1 v5,,$1 v0,$1 v1,$1 v2,$1 v3,$1 v4,$1 v5,$1 v6,,
                       $1 v0,$1 v1,$1 v2,$1 v3,$1 v4,$1 v5,$1 v6,$1 v7;;
                       \&\&\s*values\.length\s*==\s*1\s*\&\&\s*values\[0\]\s*==\s*values\[0\] ==>
                       && v0 == v0,, ,,...;;
                       values\[0\] ==> v0,,...;;
                       if\s*\(standardBehaviorForSingleFrame\s*\).*?(return\s+combining) ==> $1,,...;;
                       (get\()values ==> $1v0,,$1v0, v1,,$1v0, v1, v2,,$1v0, v1, v2, v3,,$1v0, v1, v2, v3, v4,,
                       $1v0, v1, v2, v3, v4, v5,,$1v0, v1, v2, v3, v4, v5, v6,,$1v0, v1, v2, v3, v4, v5, v6, v7
            */
            public double get(double[] coordinates, double[] values) {
                if (standardBehaviorForSingleFrame && values.length == 1 && values[0] == values[0]) { // not NaN
                    return values[0];
                }
                return combiningFunc.get(values);
            }

            public double get1D(double x0,
                double[] values)
            {
                if (standardBehaviorForSingleFrame && values.length == 1 && values[0] == values[0]) { // not NaN
                    return values[0];
                }
                return combiningFunc.get(values);
            }

            public double get2D(double x0, double x1,
                double[] values)
            {
                if (standardBehaviorForSingleFrame && values.length == 1 && values[0] == values[0]) { // not NaN
                    return values[0];
                }
                return combiningFunc.get(values);
            }

            public double get3D(double x0, double x1, double x2,
                double[] values)
            {
                if (standardBehaviorForSingleFrame && values.length == 1 && values[0] == values[0]) { // not NaN
                    return values[0];
                }
                return combiningFunc.get(values);
            }
            /*Repeat.AutoGeneratedStart !! Auto-generated: NOT EDIT !! */
            public double get(double[] coordinates, double v0) {
                if (standardBehaviorForSingleFrame && v0 == v0) { // not NaN
                    return v0;
                }
                return combiningFunc.get(v0);
            }

            public double get1D(double x0,
                double v0)
            {
                if (standardBehaviorForSingleFrame && v0 == v0) { // not NaN
                    return v0;
                }
                return combiningFunc.get(v0);
            }

            public double get2D(double x0, double x1,
                double v0)
            {
                if (standardBehaviorForSingleFrame && v0 == v0) { // not NaN
                    return v0;
                }
                return combiningFunc.get(v0);
            }

            public double get3D(double x0, double x1, double x2,
                double v0)
            {
                if (standardBehaviorForSingleFrame && v0 == v0) { // not NaN
                    return v0;
                }
                return combiningFunc.get(v0);
            }

            public double get(double[] coordinates, double v0, double v1) {
                return combiningFunc.get(v0, v1);
            }

            public double get1D(double x0,
                double v0, double v1)
            {
                return combiningFunc.get(v0, v1);
            }

            public double get2D(double x0, double x1,
                double v0, double v1)
            {
                return combiningFunc.get(v0, v1);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1)
            {
                return combiningFunc.get(v0, v1);
            }

            public double get(double[] coordinates, double v0, double v1, double v2) {
                return combiningFunc.get(v0, v1, v2);
            }

            public double get1D(double x0,
                double v0, double v1, double v2)
            {
                return combiningFunc.get(v0, v1, v2);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2)
            {
                return combiningFunc.get(v0, v1, v2);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2)
            {
                return combiningFunc.get(v0, v1, v2);
            }

            public double get(double[] coordinates, double v0, double v1, double v2, double v3) {
                return combiningFunc.get(v0, v1, v2, v3);
            }

            public double get1D(double x0,
                double v0, double v1, double v2, double v3)
            {
                return combiningFunc.get(v0, v1, v2, v3);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2, double v3)
            {
                return combiningFunc.get(v0, v1, v2, v3);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2, double v3)
            {
                return combiningFunc.get(v0, v1, v2, v3);
            }

            public double get(double[] coordinates, double v0, double v1, double v2, double v3, double v4) {
                return combiningFunc.get(v0, v1, v2, v3, v4);
            }

            public double get1D(double x0,
                double v0, double v1, double v2, double v3, double v4)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2, double v3, double v4)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2, double v3, double v4)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4);
            }

            public double get(double[] coordinates, double v0, double v1, double v2, double v3, double v4, double v5) {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5);
            }

            public double get1D(double x0,
                double v0, double v1, double v2, double v3, double v4, double v5)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2, double v3, double v4, double v5)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2, double v3, double v4, double v5)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5);
            }

            public double get(double[] coordinates, double v0, double v1, double v2, double v3, double v4, double v5, double v6) {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6);
            }

            public double get1D(double x0,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6);
            }

            public double get(double[] coordinates, double v0, double v1, double v2, double v3, double v4, double v5, double v6, double v7) {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6, v7);
            }

            public double get1D(double x0,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6, double v7)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6, v7);
            }

            public double get2D(double x0, double x1,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6, double v7)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6, v7);
            }

            public double get3D(double x0, double x1, double x2,
                double v0, double v1, double v2, double v3, double v4, double v5, double v6, double v7)
            {
                return combiningFunc.get(v0, v1, v2, v3, v4, v5, v6, v7);
            }
            /*Repeat.AutoGeneratedEnd*/

            public String toString() {
                return "stitching function ignoring coordinates based on " + combiningFunc;
            }
        };
    }

    /**
     * Returns a brief string description of this object.
     *
     * @return a brief string description of this object.
     */
    public String toString() {
        return "simple stitching method (ignoring coordinates) based on " + combiningFunc;
    }
}