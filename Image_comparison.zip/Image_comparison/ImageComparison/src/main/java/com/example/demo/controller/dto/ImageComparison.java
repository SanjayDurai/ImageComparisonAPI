package com.example.demo.controller.dto;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonInclude;

@RestController
@RequestMapping("/image")
public class ImageComparison {

    @PostMapping(value = "/compare", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ApiResponse> compareImages(
            @RequestParam("image1") MultipartFile image1File,
            @RequestParam("image2") MultipartFile image2File
    ) {
        try {
            BufferedImage image1 = ImageIO.read(image1File.getInputStream());
            BufferedImage image2 = ImageIO.read(image2File.getInputStream());

            if (image1 == null || image2 == null) {
                return new ResponseEntity<>(new ApiResponse("Error reading image files", 0), HttpStatus.BAD_REQUEST);
            }

            BufferedImage resizedImage1 = resizeImage(image1, image2.getWidth(), image2.getHeight());
            double percentageDifference = calculatePercentageDifference(resizedImage1, image2);

            ApiResponse response = new ApiResponse("Images compared successfully", percentageDifference);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException(e.getMessage());
        }
    }

    private BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        Image scaledImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
        BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
        resizedImage.getGraphics().drawImage(scaledImage, 0, 0, null);
        return resizedImage;
    }


    private double calculatePercentageDifference(BufferedImage image1, BufferedImage image2) {

        double pixelDifference = calculatePixelDifference(image1, image2);

        return pixelDifference * 100.0;
    }

    private double calculatePixelDifference(BufferedImage image1, BufferedImage image2) {



        int totalPixels = image1.getWidth() * image1.getHeight();
        int differentPixels = 0;


        for (int y = 0; y < image1.getHeight(); y++) {
            for (int x = 0; x < image1.getWidth(); x++) {
                int rgb1 = image1.getRGB(x, y);
                int rgb2 = image2.getRGB(x, y);

                if (rgb1 != rgb2) {
                    differentPixels++;
                }
            }
        }
//        System.out.printf("calculatePixelDifference :: " +( differentPixels / totalPixels ));

        return (double) differentPixels / totalPixels;
    }

}



@JsonInclude(JsonInclude.Include.NON_NULL)
class ApiResponse {
    private String message;
    private double percentageDifference;


    public ApiResponse(String message, double percentageDifference) {

//        System.out.println("percentageDifference::" + percentageDifference);
//        System.out.println("String message ::" +  message);
        this.message = message;
        this.percentageDifference = percentageDifference;
    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public double getPercentageDifference() {
        return percentageDifference;
    }

    public void setPercentageDifference(double percentageDifference) {
        this.percentageDifference = percentageDifference;
    }

    @Override
    public String toString() {
        return "ApiResponse{" +
                "message='" + message + '\'' +
                ", percentageDifference=" + percentageDifference +
                '}';
    }
}

