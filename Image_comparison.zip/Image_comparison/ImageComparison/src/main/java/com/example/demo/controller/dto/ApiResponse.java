import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
class ApiResponse {
    private String message;
    private double percentageDifference;


    public ApiResponse(String message, double percentageDifference) {

        this.message = message;
        this.percentageDifference = percentageDifference;
    }


}